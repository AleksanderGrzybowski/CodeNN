#! /bin/sh
/home/kelog/modem.rb &
