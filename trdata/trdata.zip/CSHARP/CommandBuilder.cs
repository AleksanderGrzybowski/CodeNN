// Copyright (c) .NET Foundation. All rights reserved.
// Licensed under the Apache License, Version 2.0. See License.txt in the project root for license information.

using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Threading;
using JetBrains.Annotations;
using Microsoft.Data.Entity.Relational.Query.Sql;
using Microsoft.Data.Entity.Utilities;

namespace Microsoft.Data.Entity.Relational.Query
{
    public class CommandBuilder
    {
        private readonly IRelationalValueBufferFactoryFactory _valueBufferFactoryFactory;
        private readonly Func<ISqlQueryGenerator> _sqlGeneratorFactory;

        private IRelationalValueBufferFactory _valueBufferFactory;

        public CommandBuilder(
            [NotNull] Func<ISqlQueryGenerator> sqlGeneratorFactory,
            [NotNull] IRelationalValueBufferFactoryFactory valueBufferFactoryFactory)
        {
            Check.NotNull(sqlGeneratorFactory, nameof(sqlGeneratorFactory));
            Check.NotNull(valueBufferFactoryFactory, nameof(valueBufferFactoryFactory));

            _sqlGeneratorFactory = sqlGeneratorFactory;
            _valueBufferFactoryFactory = valueBufferFactoryFactory;
        }

        public virtual IRelationalValueBufferFactory ValueBufferFactory => _valueBufferFactory;

        public virtual DbCommand Build(
            [NotNull] IRelationalConnection connection,
            [NotNull] IDictionary<string, object> parameterValues)
        {
            Check.NotNull(connection, nameof(connection));

            // TODO: Cache command...

            var command = connection.DbConnection.CreateCommand();

            if (connection.Transaction != null)
            {
                command.Transaction = connection.Transaction.DbTransaction;
            }

            if (connection.CommandTimeout != null)
            {
                command.CommandTimeout = (int)connection.CommandTimeout;
            }

            var sqlQueryGenerator = _sqlGeneratorFactory();

            command.CommandText = sqlQueryGenerator.GenerateSql(parameterValues);

            foreach (var commandParameter in sqlQueryGenerator.Parameters)
            {
                var parameter = command.CreateParameter();

                parameter.ParameterName = commandParameter.Name;
                parameter.Value = commandParameter.Value;

                // TODO: Parameter facets?

                command.Parameters.Add(parameter);
            }

            return command;
        }

        public virtual void NotifyReaderCreated([NotNull] DbDataReader dataReader)
        {
            Check.NotNull(dataReader, nameof(dataReader));

            LazyInitializer
                .EnsureInitialized(
                    ref _valueBufferFactory,
                    () => _sqlGeneratorFactory()
                        .CreateValueBufferFactory(_valueBufferFactoryFactory, dataReader));
        }
    }
}
