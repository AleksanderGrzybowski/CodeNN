#include "HardEnemy.h"

HardEnemy::HardEnemy(double xpos, double ypos)
	: Enemy(xpos, ypos, {"Sprites/HardEnemy.png"}, 64, 100, 0.2, 30, 5)
{}
