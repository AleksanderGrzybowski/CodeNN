#include "SimpleBonus.h"

SimpleBonus::SimpleBonus(double xpos, double ypos)
	: Bonus(xpos, ypos, {"Sprites/SimpleBonus.png"}, 32, 1337, 0.1, 10)
{}
